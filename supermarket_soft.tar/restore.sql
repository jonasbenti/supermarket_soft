--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.23
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE supermarket_soft;
--
-- Name: supermarket_soft; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE supermarket_soft WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE supermarket_soft OWNER TO postgres;

\connect supermarket_soft

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: supermarket_soft; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA supermarket_soft;


ALTER SCHEMA supermarket_soft OWNER TO postgres;

--
-- Name: SCHEMA supermarket_soft; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA supermarket_soft IS 'standard public schema';


SET default_tablespace = '';

--
-- Name: order_sale_item; Type: TABLE; Schema: supermarket_soft; Owner: postgres
--

CREATE TABLE supermarket_soft.order_sale_item (
    id integer NOT NULL,
    order_sale_id integer,
    product_id integer,
    product_desc character varying(100),
    quantity numeric(10,2),
    price numeric(10,2),
    value_total numeric(10,2),
    value_total_tax numeric(10,2),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE supermarket_soft.order_sale_item OWNER TO postgres;

--
-- Name: item_order_sale_id_seq; Type: SEQUENCE; Schema: supermarket_soft; Owner: postgres
--

CREATE SEQUENCE supermarket_soft.item_order_sale_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE supermarket_soft.item_order_sale_id_seq OWNER TO postgres;

--
-- Name: item_order_sale_id_seq; Type: SEQUENCE OWNED BY; Schema: supermarket_soft; Owner: postgres
--

ALTER SEQUENCE supermarket_soft.item_order_sale_id_seq OWNED BY supermarket_soft.order_sale_item.id;


--
-- Name: order_sale; Type: TABLE; Schema: supermarket_soft; Owner: postgres
--

CREATE TABLE supermarket_soft.order_sale (
    id integer NOT NULL,
    order_date date,
    order_total numeric(10,2),
    order_total_tax numeric(10,2),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE supermarket_soft.order_sale OWNER TO postgres;

--
-- Name: order_sale_id_seq; Type: SEQUENCE; Schema: supermarket_soft; Owner: postgres
--

CREATE SEQUENCE supermarket_soft.order_sale_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE supermarket_soft.order_sale_id_seq OWNER TO postgres;

--
-- Name: order_sale_id_seq; Type: SEQUENCE OWNED BY; Schema: supermarket_soft; Owner: postgres
--

ALTER SEQUENCE supermarket_soft.order_sale_id_seq OWNED BY supermarket_soft.order_sale.id;


--
-- Name: product; Type: TABLE; Schema: supermarket_soft; Owner: postgres
--

CREATE TABLE supermarket_soft.product (
    id integer NOT NULL,
    type_product_id integer,
    description character varying(100),
    value numeric(10,2),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE supermarket_soft.product OWNER TO postgres;

--
-- Name: product_id_seq; Type: SEQUENCE; Schema: supermarket_soft; Owner: postgres
--

CREATE SEQUENCE supermarket_soft.product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE supermarket_soft.product_id_seq OWNER TO postgres;

--
-- Name: product_id_seq; Type: SEQUENCE OWNED BY; Schema: supermarket_soft; Owner: postgres
--

ALTER SEQUENCE supermarket_soft.product_id_seq OWNED BY supermarket_soft.product.id;


--
-- Name: type_product; Type: TABLE; Schema: supermarket_soft; Owner: postgres
--

CREATE TABLE supermarket_soft.type_product (
    id integer NOT NULL,
    description character varying(100),
    tax_percentage numeric(5,2),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE supermarket_soft.type_product OWNER TO postgres;

--
-- Name: type_product_id_seq; Type: SEQUENCE; Schema: supermarket_soft; Owner: postgres
--

CREATE SEQUENCE supermarket_soft.type_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE supermarket_soft.type_product_id_seq OWNER TO postgres;

--
-- Name: type_product_id_seq; Type: SEQUENCE OWNED BY; Schema: supermarket_soft; Owner: postgres
--

ALTER SEQUENCE supermarket_soft.type_product_id_seq OWNED BY supermarket_soft.type_product.id;


--
-- Name: order_sale id; Type: DEFAULT; Schema: supermarket_soft; Owner: postgres
--

ALTER TABLE ONLY supermarket_soft.order_sale ALTER COLUMN id SET DEFAULT nextval('supermarket_soft.order_sale_id_seq'::regclass);


--
-- Name: order_sale_item id; Type: DEFAULT; Schema: supermarket_soft; Owner: postgres
--

ALTER TABLE ONLY supermarket_soft.order_sale_item ALTER COLUMN id SET DEFAULT nextval('supermarket_soft.item_order_sale_id_seq'::regclass);


--
-- Name: product id; Type: DEFAULT; Schema: supermarket_soft; Owner: postgres
--

ALTER TABLE ONLY supermarket_soft.product ALTER COLUMN id SET DEFAULT nextval('supermarket_soft.product_id_seq'::regclass);


--
-- Name: type_product id; Type: DEFAULT; Schema: supermarket_soft; Owner: postgres
--

ALTER TABLE ONLY supermarket_soft.type_product ALTER COLUMN id SET DEFAULT nextval('supermarket_soft.type_product_id_seq'::regclass);


--
-- Data for Name: order_sale; Type: TABLE DATA; Schema: supermarket_soft; Owner: postgres
--

COPY supermarket_soft.order_sale (id, order_date, order_total, order_total_tax, created_at, updated_at) FROM stdin;
\.
COPY supermarket_soft.order_sale (id, order_date, order_total, order_total_tax, created_at, updated_at) FROM '$$PATH$$/2137.dat';

--
-- Data for Name: order_sale_item; Type: TABLE DATA; Schema: supermarket_soft; Owner: postgres
--

COPY supermarket_soft.order_sale_item (id, order_sale_id, product_id, product_desc, quantity, price, value_total, value_total_tax, created_at, updated_at) FROM stdin;
\.
COPY supermarket_soft.order_sale_item (id, order_sale_id, product_id, product_desc, quantity, price, value_total, value_total_tax, created_at, updated_at) FROM '$$PATH$$/2139.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: supermarket_soft; Owner: postgres
--

COPY supermarket_soft.product (id, type_product_id, description, value, created_at, updated_at) FROM stdin;
\.
COPY supermarket_soft.product (id, type_product_id, description, value, created_at, updated_at) FROM '$$PATH$$/2135.dat';

--
-- Data for Name: type_product; Type: TABLE DATA; Schema: supermarket_soft; Owner: postgres
--

COPY supermarket_soft.type_product (id, description, tax_percentage, created_at, updated_at) FROM stdin;
\.
COPY supermarket_soft.type_product (id, description, tax_percentage, created_at, updated_at) FROM '$$PATH$$/2133.dat';

--
-- Name: item_order_sale_id_seq; Type: SEQUENCE SET; Schema: supermarket_soft; Owner: postgres
--

SELECT pg_catalog.setval('supermarket_soft.item_order_sale_id_seq', 7, true);


--
-- Name: order_sale_id_seq; Type: SEQUENCE SET; Schema: supermarket_soft; Owner: postgres
--

SELECT pg_catalog.setval('supermarket_soft.order_sale_id_seq', 42, true);


--
-- Name: product_id_seq; Type: SEQUENCE SET; Schema: supermarket_soft; Owner: postgres
--

SELECT pg_catalog.setval('supermarket_soft.product_id_seq', 5, true);


--
-- Name: type_product_id_seq; Type: SEQUENCE SET; Schema: supermarket_soft; Owner: postgres
--

SELECT pg_catalog.setval('supermarket_soft.type_product_id_seq', 3, true);


--
-- Name: order_sale_item item_order_sale_pkey; Type: CONSTRAINT; Schema: supermarket_soft; Owner: postgres
--

ALTER TABLE ONLY supermarket_soft.order_sale_item
    ADD CONSTRAINT item_order_sale_pkey PRIMARY KEY (id);


--
-- Name: order_sale order_sale_pkey; Type: CONSTRAINT; Schema: supermarket_soft; Owner: postgres
--

ALTER TABLE ONLY supermarket_soft.order_sale
    ADD CONSTRAINT order_sale_pkey PRIMARY KEY (id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: supermarket_soft; Owner: postgres
--

ALTER TABLE ONLY supermarket_soft.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- Name: type_product type_product_pkey; Type: CONSTRAINT; Schema: supermarket_soft; Owner: postgres
--

ALTER TABLE ONLY supermarket_soft.type_product
    ADD CONSTRAINT type_product_pkey PRIMARY KEY (id);


--
-- Name: order_sale_item fk_order_sale; Type: FK CONSTRAINT; Schema: supermarket_soft; Owner: postgres
--

ALTER TABLE ONLY supermarket_soft.order_sale_item
    ADD CONSTRAINT fk_order_sale FOREIGN KEY (order_sale_id) REFERENCES supermarket_soft.order_sale(id);


--
-- Name: order_sale_item fk_product_id; Type: FK CONSTRAINT; Schema: supermarket_soft; Owner: postgres
--

ALTER TABLE ONLY supermarket_soft.order_sale_item
    ADD CONSTRAINT fk_product_id FOREIGN KEY (product_id) REFERENCES supermarket_soft.product(id);


--
-- Name: product fk_type_product; Type: FK CONSTRAINT; Schema: supermarket_soft; Owner: postgres
--

ALTER TABLE ONLY supermarket_soft.product
    ADD CONSTRAINT fk_type_product FOREIGN KEY (type_product_id) REFERENCES supermarket_soft.type_product(id);


--
-- Name: SCHEMA supermarket_soft; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA supermarket_soft FROM PUBLIC;
REVOKE ALL ON SCHEMA supermarket_soft FROM postgres;
GRANT ALL ON SCHEMA supermarket_soft TO postgres;
GRANT ALL ON SCHEMA supermarket_soft TO PUBLIC;


--
-- PostgreSQL database dump complete
--

